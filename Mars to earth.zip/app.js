const express = require('express');
const bodyParser = require('body-parser');
const earthMarsController = require('./earthMarsController');

const app = express();
app.use(express.json());
app.use(bodyParser.json());

app.use('/api/earth-mars-comm', earthMarsController);

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
