const express = require('express');
const router = express.Router();
const messages = {}; // In-memory storage for messages

// ... Mapping and translation functions ...
const logSenderReceiver = (req, res, next) => {
    const sender = req.headers['x-sender'];
    const receiver = req.headers['x-receiver'];

    console.log(`Sender: ${sender} | Receiver: ${receiver}`);
    next();
};

const logProcessingTime = (req, res, next) => {
    const startTime = new Date();

    res.on('finish', () => {
        const endTime = new Date();
        const processingTime = endTime - startTime;
        console.log(`Processing Time: ${processingTime}ms`);
    });

    next();
};
const englishToNumeric = {
    'a': '2', 'b': '22', 'c': '222',
    'd': '3', 'e': '33', 'f': '333',
    'g': '4', 'h': '44', 'i': '444',
    'j': '5', 'k': '55', 'l': '555',
    'm': '6', 'n': '66', 'o': '666',
    'p': '7', 'q': '77', 'r': '777', 's': '7777',
    't': '8', 'u': '88', 'v': '888',
    'w': '9', 'x': '99', 'y': '999', 'z': '9999',
    ' ': '0'
};

function englishToNokia(message) {
    let numericMessage = '';
    console.log(message, 'message1');
    for (const char of message) {
        numericMessage += englishToNumeric[char.toLowerCase()] || '';
    }

    return numericMessage;
}


const numericToEnglishWithSplitter = {
    '2': 'a', '22': 'b', '222': 'c',
    '3': 'd', '33': 'e', '333': 'f',
    '4': 'g', '44': 'h', '444': 'i',
    '5': 'j', '55': 'k', '555': 'l',
    '6': 'm', '66': 'n', '666': 'o',
    '7': 'p', '77': 'q', '777': 'r', '7777': 's',
    '8': 't', '88': 'u', '888': 'v',
    '9': 'w', '99': 'x', '999': 'y', '9999': 'z',
    '0': ' ', '.': '.'
};
function nokiaToEnglishWithSplitter(numericMessage) {
    var numericList = ""
    if (numericMessage.result) {
        numericList = numericMessage.result.split(' ');
        // numericMessage = numericMessage.result

    } else {
        numericList = numericMessage
    }

    let englishTranslation = '';

    for (const num of numericList) {
        let currentNumeric = '';
        let partialTranslation = '';

        for (const digit of num) {
            currentNumeric += digit;

            if (numericToEnglishWithSplitter[currentNumeric]) {
                partialTranslation = numericToEnglishWithSplitter[currentNumeric];
            }
        }

        englishTranslation += partialTranslation;
    }
    return englishTranslation;
}
function englishToNokia(message) {
    let numericMessage = '';
    if (message.result) {
        message = message.result

    } else {
        message = message
    }
    for (const char of message) {
        numericMessage += englishToNumeric[char.toLowerCase()] || '';
    }

    return numericMessage;
}




function translateMessage(message, sender, receiver) {
    let result = "";
    if (sender === 'earth' && receiver === 'mars') {


        result = englishToNokia(message);
    } else {

        result = nokiaToEnglishWithSplitter(message);
    }

    return result;
}

router.use((req, res, next) => {
    const sender = req.headers['x-sender'];
    const receiver = req.headers['x-receiver'];

    // Intercept the response and modify it based on sender and receiver
    const originalJson = res.json.bind(res);
    res.json = (body) => {
        let modifiedBody = body;

        if (sender === 'earth' && receiver === 'mars') {
            modifiedBody = { 'Response from Mars': body, 'Nokia Translation': translateMessage(body, sender, receiver) };
        } else {
            modifiedBody = { 'Response from Earth': body, 'Nokia Translation': translateMessage(body, sender, receiver) };
        }

        originalJson(modifiedBody);
    };

    next();
});

router.post('/message', logSenderReceiver, logProcessingTime, (req, res) => {
    const message = req.body.message; // Ensure req.body.message exists
    console.log('Received Message:', message);

    const sender = req.headers['x-sender'];
    const receiver = req.headers['x-receiver'];

    messages[sender] = message; // Store the message in-memory

    const result = translateMessage(message, sender, receiver);

    res.json({ result });
});



//  



module.exports = router;
